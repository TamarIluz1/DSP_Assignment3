package com.dsp.dirt.job;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import static com.dsp.dirt.util.Keys.PS;
import static com.dsp.dirt.util.Keys.S;
import static com.dsp.dirt.util.Keys.SW;
import static com.dsp.dirt.util.Keys.T;

public class ComputeMIJob {

    /**
     * Input lines are: KEY \t COUNT
     * where KEY is one of:
     *  T\tp\tslot\tw
     *  PS\tp\tslot
     *  SW\tslot\tw
     *  S\tslot\t*
     */
    public static class M extends Mapper<LongWritable, Text, Text, Text> {
        private final Text outK = new Text();
        private final Text outV = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context ctx) throws IOException, InterruptedException {
            String line = value.toString();
            int lastTab = line.lastIndexOf('\t');
            if (lastTab < 0) return;

            String kPart = line.substring(0, lastTab);
            String cPart = line.substring(lastTab + 1);

            String[] fields = kPart.split("\\t");
            if (fields.length < 2) return;

            String type = fields[0];

            // Partition by slot so reducer has all needed totals for that slot
            if (type.equals(S) && fields.length == 3) {
                String slot = fields[1];
                outK.set(slot);
                outV.set("S\t" + cPart);
                ctx.write(outK, outV);
            } else if (type.equals(SW) && fields.length == 3) {
                String slot = fields[1], w = fields[2];
                outK.set(slot);
                outV.set("SW\t" + w + "\t" + cPart);
                ctx.write(outK, outV);
            } else if (type.equals(PS) && fields.length == 3) {
                String p = fields[1], slot = fields[2];
                outK.set(slot);
                outV.set("PS\t" + p + "\t" + cPart);
                ctx.write(outK, outV);
            } else if (type.equals(T) && fields.length == 4) {
                String p = fields[1], slot = fields[2], w = fields[3];
                outK.set(slot);
                outV.set("T\t" + p + "\t" + w + "\t" + cPart);
                ctx.write(outK, outV);
            }
        }
    }

    public static class R extends Reducer<Text, Text, Text, DoubleWritable> {

        // Output key format: p \t slot \t w
        private final Text outK = new Text();
        private final DoubleWritable outV = new DoubleWritable();

        @Override
        protected void reduce(Text slotKey, Iterable<Text> vals, Context ctx) throws IOException, InterruptedException {
            long c_s = -1L; // (*,slot,*)
            Map<String, Long> c_sw = new HashMap<>(); // w -> (*,slot,w)
            Map<String, Long> c_ps = new HashMap<>(); // p -> (p,slot,*)

            // T records stored until totals loaded
            List<String[]> triples = new ArrayList<>(); // each: [p, w, c_psw]

            for (Text tv : vals) {
                String[] f = tv.toString().split("\\t");
                if (f.length == 0) continue;

                switch (f[0]) {
                    case "S":
                        c_s = parseLongSafe(f[1]);
                        break;
                    case "SW":
                        if (f.length >= 3) c_sw.put(f[1], parseLongSafe(f[2]));
                        break;
                    case "PS":
                        if (f.length >= 3) c_ps.put(f[1], parseLongSafe(f[2]));
                        break;
                    case "T":
                        if (f.length >= 4) triples.add(new String[]{f[1], f[2], f[3]});
                        break;
                }
            }

            if (c_s <= 0) return;

            for (String[] t : triples) {
                String p = t[0];
                String w = t[1];
                long c_psw = parseLongSafe(t[2]);

                Long c_ps_val = c_ps.get(p);
                Long c_sw_val = c_sw.get(w);
                if (c_ps_val == null || c_sw_val == null) continue;
                if (c_psw <= 0 || c_ps_val <= 0 || c_sw_val <= 0) continue;

                // TODO: confirm exact MI formula/log base for your report.
                // Standard DIRT-style MI:
                // mi = log( (c_psw * c_s) / (c_ps * c_sw) )
                double num = (double) c_psw * (double) c_s;
                double den = (double) c_ps_val * (double) c_sw_val;
                if (den <= 0) continue;

                double mi = Math.log(num / den); // natural log
                outK.set(p + "\t" + slotKey.toString() + "\t" + w);
                outV.set(mi);
                ctx.write(outK, outV);
            }
        }

            private long parseLongSafe(String s) {
                try { return Long.parseLong(s.trim()); }
                catch (Exception e) { return -1L; }
            }
    }

    public static Job build(Configuration conf, Path in, Path out) throws IOException {
        Job job = Job.getInstance(conf, "B_compute_mi");
        job.setJarByClass(ComputeMIJob.class);

        job.setMapperClass(M.class);
        job.setReducerClass(R.class);
        job.setNumReduceTasks(2);


        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        TextInputFormat.addInputPath(job, in);
        TextOutputFormat.setOutputPath(job, out);

        return job;
    }


}
