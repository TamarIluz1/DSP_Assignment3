package com.dsp.dirt.extract;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dsp.dirt.parse.BiarcsRecord;
import com.dsp.dirt.parse.BiarcsToken;

import static com.dsp.dirt.util.Keys.X;
import static com.dsp.dirt.util.Keys.Y;

public class PathExtractor {

    private final Stemmer stemmer = new Stemmer();

    // Java-8 safe (no Set.of)
    private static final Set<String> FILTER_AUX;
    static {
        Set<String> s = new HashSet<String>(Arrays.asList(
                "do","does","did",
                "have","has","had",
                "can","could","will","would","shall","should","may","might","must"
        ));
        FILTER_AUX = Collections.unmodifiableSet(s);
    }

    public List<PathInstance> extract(BiarcsRecord r) {
        if (r == null || !r.isValid() || r.tokens == null || r.tokens.isEmpty()) {
            return Collections.emptyList();
        }

        int n = r.tokens.size();
        BiarcsToken[] tok = new BiarcsToken[n + 1];
        for (BiarcsToken t : r.tokens) {
            if (t != null && t.index >= 1 && t.index <= n) {
                tok[t.index] = t;
            }
        }

        int[] parent = new int[n + 1];
        for (int i = 1; i <= n; i++) {
            if (tok[i] == null) continue;
            int h = tok[i].headIndex;
            parent[i] = (h >= 0 && h <= n) ? h : 0;
        }

        List<Integer> nouns = new ArrayList<Integer>();
        for (int i = 1; i <= n; i++) {
            if (tok[i] != null && isNoun(tok[i].pos) && isGoodWord(tok[i].word)) {
                nouns.add(i);
            }
        }
        if (nouns.size() < 2) return Collections.emptyList();

        long count = r.totalCount;
        if (count <= 0) return Collections.emptyList();

        List<PathInstance> out = new ArrayList<PathInstance>();

        for (int aPos = 0; aPos < nouns.size(); aPos++) {
            for (int bPos = aPos + 1; bPos < nouns.size(); bPos++) {
                int a = nouns.get(aPos);
                int b = nouns.get(bPos);

                int l = lca(a, b, parent);
                if (l == 0 || tok[l] == null) continue;

                // requirement: head must be a verb
                if (!isVerb(tok[l].pos)) continue;

                // optional auxiliary filtering
                String head = stemmer.stem(tok[l].word);
                if (FILTER_AUX.contains(head)) continue;

                List<Integer> path = dependencyPath(a, b, l, parent);
                if (path.isEmpty()) continue;

                String pXY = buildPredicate(path, tok, a, b);
                if (!pXY.isEmpty()) {
                    out.add(new PathInstance(pXY, X, stemmer.stem(tok[a].word), count));
                    out.add(new PathInstance(pXY, Y, stemmer.stem(tok[b].word), count));
                }

                String pYX = buildPredicate(path, tok, b, a);
                if (!pYX.isEmpty()) {
                    out.add(new PathInstance(pYX, X, stemmer.stem(tok[b].word), count));
                    out.add(new PathInstance(pYX, Y, stemmer.stem(tok[a].word), count));
                }
            }
        }

        return out;
    }

    private String buildPredicate(List<Integer> path, BiarcsToken[] tok, int xIdx, int yIdx) {
        List<String> parts = new ArrayList<String>();

        for (int idx : path) {
            if (idx == xIdx) { parts.add("X"); continue; }
            if (idx == yIdx) { parts.add("Y"); continue; }

            BiarcsToken t = tok[idx];
            if (t == null) continue;

            if (!shouldIncludeInPredicate(t.pos)) continue;
            if (!isGoodWord(t.word)) continue;

            parts.add(stemmer.stem(t.word));
        }

        parts = collapseAdjacent(parts);

        if (!parts.contains("X") || !parts.contains("Y")) return "";
        String pred = joinWithSpace(parts).trim();

        if (pred.equals("X Y") || pred.equals("Y X")) return "";
        return pred;
    }

    private List<String> collapseAdjacent(List<String> in) {
        if (in.isEmpty()) return in;
        List<String> out = new ArrayList<String>(in.size());
        String prev = null;
        for (String s : in) {
            if (prev == null || !prev.equals(s)) out.add(s);
            prev = s;
        }
        return out;
    }

    private String joinWithSpace(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    private List<Integer> dependencyPath(int a, int b, int lca, int[] parent) {
        List<Integer> left = new ArrayList<Integer>();
        int x = a;
        while (x != 0 && x != lca) {
            left.add(x);
            x = parent[x];
        }
        left.add(lca);

        List<Integer> right = new ArrayList<Integer>();
        int y = b;
        while (y != 0 && y != lca) {
            right.add(y);
            y = parent[y];
        }
        Collections.reverse(right);

        List<Integer> path = new ArrayList<Integer>(left.size() + right.size());
        path.addAll(left);
        path.addAll(right);
        return path;
    }

    private int lca(int a, int b, int[] parent) {
        Set<Integer> anc = new HashSet<Integer>();
        int x = a;
        while (x != 0) {
            anc.add(x);
            x = parent[x];
        }
        int y = b;
        while (y != 0) {
            if (anc.contains(y)) return y;
            y = parent[y];
        }
        return 0;
    }

    private boolean isNoun(String pos) { return pos != null && pos.startsWith("NN"); }
    private boolean isVerb(String pos) { return pos != null && pos.startsWith("VB"); }

    private boolean shouldIncludeInPredicate(String pos) {
        if (pos == null) return false;
        return pos.startsWith("VB") || pos.startsWith("JJ") || pos.startsWith("RB")
                || "IN".equals(pos) || "TO".equals(pos) || "RP".equals(pos);
    }

    private boolean isGoodWord(String w) {
        if (w == null) return false;
        w = w.trim();
        if (w.isEmpty()) return false;
        return !"_".equals(w);
    }
}
