package com.dsp.dirt.local;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static com.dsp.dirt.util.Keys.X;
import static com.dsp.dirt.util.Keys.Y;

public class SimilarityScorer {

    public static class Feats {
        public final Map<String, Double> x = new HashMap<String, Double>();
        public final Map<String, Double> y = new HashMap<String, Double>();
    }

    public static Map<String, Feats> loadMI(File miTsv, Set<String> neededPredicates) throws IOException {
        Map<String, Feats> out = new HashMap<String, Feats>();

        try (BufferedReader br = new BufferedReader(new FileReader(miTsv))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\t");
                if (p.length < 4) continue;

                String pred = p[0];
                if (neededPredicates != null && !neededPredicates.isEmpty() && !neededPredicates.contains(pred)) {
                    continue;
                }

                String slot = p[1];
                String arg = p[2];

                double mi;
                try {
                    mi = Double.parseDouble(p[3]);
                } catch (NumberFormatException e) {
                    continue;
                }

                Feats f = out.get(pred);
                if (f == null) {
                    f = new Feats();
                    out.put(pred, f);
                }

                if (X.equals(slot)) {
                    f.x.put(arg, mi);
                } else if (Y.equals(slot)) {
                    f.y.put(arg, mi);
                }
            }
        }

        return out;
    }

    public static double pathSimilarity(Feats a, Feats b) {
        if (a == null || b == null) return 0.0;

        double sx = slotSimilarity(a.x, b.x);
        double sy = slotSimilarity(a.y, b.y);

        if (sx == 0.0 && sy == 0.0) return 0.0;
        return 0.5 * (sx + sy);
    }

    private static double slotSimilarity(Map<String, Double> a, Map<String, Double> b) {
        if (a == null) a = Collections.emptyMap();
        if (b == null) b = Collections.emptyMap();
        if (a.isEmpty() || b.isEmpty()) return 0.0;

        double dot = 0.0;
        double na = 0.0;
        double nb = 0.0;

        for (Map.Entry<String, Double> e : a.entrySet()) {
            double va = e.getValue() == null ? 0.0 : e.getValue();
            na += va * va;

            Double vbObj = b.get(e.getKey());
            if (vbObj != null) {
                double vb = vbObj;
                dot += va * vb;
            }
        }

        for (double vb : b.values()) {
            nb += vb * vb;
        }

        if (na == 0.0 || nb == 0.0) return 0.0;
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
}
